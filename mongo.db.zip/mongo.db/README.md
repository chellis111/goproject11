# **MongoDB CRUD Operations with `contactList` Collection**

## **Overview**

This project demonstrates how to perform basic **CRUD (Create, Read, Update, Delete)** operations in MongoDB. It uses a database named `contact` and a collection named `contactList` to manage contacts with fields such as `firstName`, `lastName`, `email`, and `age`.

---

## **Prerequisites**

To run this project, you need:

1. **MongoDB** installed and running locally or via a cloud service (like **MongoDB Atlas**).
2. **MongoDB Shell (mongosh)** installed to execute the commands.

---

## **Setup Instructions**

### 1. Start MongoDB Server

If using a local MongoDB instance:

```bash
mongodb
```

### 2. Access the MongoDB Shell

```bash
mongosh
```

### 3. Create and Use the contact Database

```javascript
use contact
```

## **CRUD Operations**

### 1. Insert a Single Contact

```javascript
db.contactList.insertOne({
  lastName: "Ben",
  firstName: "Moris",
  email: "ben@gmail.com",
  age: 26,
});
```

### 2. Insert Multiple Contacts

```javascript
db.contactList.insertMany([
  { lastName: "Kefi", firstName: "Seif", email: "kefi@gmail.com", age: 15 },
  {
    lastName: "Emilie",
    firstName: "brouge",
    email: "emilie.b@gmail.com",
    age: 40,
  },
  { lastName: "Ben", firstName: "Moris", email: "ben@gmail.com", age: 26 },
  { lastName: "Alex", firstName: "brown", age: 4 },
  { lastName: "Denzel", firstName: "Washington", age: 3 },
]);
```

### 3. Display All Contacts

```javascript
db.contactList.find({});
```

### 4. Display Contacts with Age > 18

```javascript
db.contactList.find({ age: { $gt: 18 } });
```

### 5. Update Contact’s First Name from "Seif" to "Anis"

```javascript
db.contactList.updateOne(
  { lastName: "Kefi", firstName: "Seif" },
  { $set: { firstName: "Anis" } }
);
```

### 6. Delete Contacts Aged Under 5

```javascript
db.contactList.deleteMany({ age: { $lt: 5 } });
```

### 7. Display All Contacts After Deletion

```javascript
db.contactList.find({});
```

## Project Structure

```bash
/project-directory
│
├── README.md             # Documentation file
└── CRUD-operations.js    # Optional: Node.js script for CRUD operations (if used)
```

## License

This project is licensed under the MIT License.

```yaml

---

### **Previewing Markdown in VS Code**

1. **Right-click** inside `README.md` and select **"Open Preview"** or use the shortcut:
   - Windows/Linux: `Ctrl + Shift + V`
   - Mac: `Cmd + Shift + V`

This will allow you to view the Markdown content in a rendered format directly inside VS Code.

---

Now you have a properly formatted `README.md` file ready to use in **VS Code**! 🎉
```
