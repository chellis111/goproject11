/**
 * insert single contact on contactList collection on database
 */
db.contactList.insertOne({ 
    lastName: "Ben", 
    firstName: "Moris", 
    email: "ben@gmail.com", 
    age: 26 
});

/**
 * check all contacts document on contactList collection
 */
db.contactList.find({});

/**
 * insert multiple contacts on contactList collection on contact database
 */

db.contactList.insertMany([
    { lastName: "kefi", firstName: "seif", gmail: "kefi@gmail.com", age: 15 },
    { lastName: "Emilie", firstName: "brouge", gmail: "emilie.b@gmail.com", age: 40 },
    { lastName: "Ben", firstName: "Moris", gmail: "ben@gmail.com", age: 26 },
    { lastName: "alex", firstName: "brown", age: 4 },
    { lastName: "Denzel", firstName: "Washington", age: 3 }
]);


// Display all the contacts with an age >18.
db.contactList.find({ age: { $gt: 18} });

// Change the contact's first name from"Kefi Seif" to "Kefi Anis"
db.contactList.update(
    {
        "lastName": "Kefi",
        "firstName": "Seif"
    }
);

// Delete the contacts that are aged under <5
db.contactList.delete({ age: {$lt: 5} })

// Display all of the contacts list
db.contactList.find({});